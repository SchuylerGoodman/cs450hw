package histogram;

import java.awt.geom.Point2D;
import java.util.List;

/**
 * Created by BaronVonBaerenstein on 1/22/2016.
 */
public interface IHistogramBucket extends List<Pixel> {
}
